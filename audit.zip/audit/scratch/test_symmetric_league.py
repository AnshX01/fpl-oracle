import pandas as pd
from fpl_oracle.league.montecarlo import monte_carlo_simulator

user_squad = pd.DataFrame([
    {"element": i, "position": "MID", "team": 1, "expected_points": 5.0, "variance": 4.0, "is_starter": True}
    for i in range(1, 16)
])
projections = pd.DataFrame([
    {"element": i, "position": "MID", "team": 1, "expected_points": 5.0, "variance": 4.0}
    for i in range(1, 30)
])

# Two completely symmetric rivals with identical squads and points
rivals = [
    {
        "entry_id": 101,
        "player_name": "Rival Symmetric",
        "total_points": 300.0,
        "captain_element": 1,
        "squad": [{"element": i, "is_starter": True} for i in range(1, 12)],
    }
]

res = monte_carlo_simulator.simulate_league(
    user_points=300.0,
    user_squad_df=user_squad,
    rival_squads=rivals,
    projections_df=projections,
    horizon_gws=1,
    seed=42,
    n_simulations=10000,
)

print("Status:", res.get("status"))
print("User win prob:", res.get("user_win_probability_pct"))
print("User top 3 prob:", res.get("user_top3_probability_pct"))
print("Rival probs summary:")
for r in res.get("rival_probabilities", []):
    print(" ", r)
