import pandas as pd
from fpl_oracle.chips.planner import ChipPlanner
from fpl_oracle.api.models import BootstrapStatic

planner = ChipPlanner()

squad_rows = (
    [{"element": i, "web_name": f"GKP_{i}", "position": "GKP", "expected_points": 3.0, "is_starter": i == 1} for i in range(1, 3)] +
    [{"element": i, "web_name": f"DEF_{i}", "position": "DEF", "expected_points": 3.0, "is_starter": i <= 5} for i in range(3, 8)] +
    [{"element": i, "web_name": f"MID_{i}", "position": "MID", "expected_points": 3.5, "is_starter": i <= 12} for i in range(8, 13)] +
    [{"element": i, "web_name": f"FWD_{i}", "position": "FWD", "expected_points": 3.0, "is_starter": i <= 14} for i in range(13, 16)]
)
squad = pd.DataFrame(squad_rows)

boot = BootstrapStatic(events=[], game_settings={}, phases=[], teams=[], total_players=0, elements=[], element_types=[])

res = planner.generate_chip_strategy(
    current_gw=19,
    current_squad_df=squad,
    horizon_projections={19: squad},
    fixtures=[],
    bootstrap=boot,
    manager_history=None,
)

print("Set 1 Warning:")
print(res.get("set_1_warning"))
print("\nPlan table for Set 1 chips in GW19:")
for c in res.get("chip_plan_table", []):
    if c.get("set") == 1:
        print(f"Chip: {c['chip']} | Rec GW: {c['recommended_gw']} | Expected gain: {c['expected_gain']} | Threshold: {c['recommendation_threshold']} | Is recommended this GW: {c['is_recommended_this_gw']}")
