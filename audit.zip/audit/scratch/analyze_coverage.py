import json
from pathlib import Path

cov_file = Path("audit/coverage.json")
if not cov_file.exists():
    print("audit/coverage.json not found!")
    exit(1)

with open(cov_file, "r", encoding="utf-8") as f:
    data = json.load(f)

files_data = data.get("files", {})

below_90 = []
branches_uncovered = {}

target_modules = ["rules", "optimise", "ml/ensemble.py", "league/montecarlo.py", "league/scenarios.py"]

for fpath, fstats in files_data.items():
    summary = fstats.get("summary", {})
    num_statements = summary.get("num_statements", 0)
    covered_lines = summary.get("covered_lines", 0)
    line_cov_pct = (covered_lines / num_statements * 100.0) if num_statements > 0 else 100.0
    
    num_branches = summary.get("num_branches", 0)
    covered_branches = summary.get("covered_branches", 0)
    
    missing_branches = fstats.get("missing_branches", [])
    missing_lines = fstats.get("missing_lines", [])

    if line_cov_pct < 90.0:
        below_90.append({
            "path": fpath,
            "statements": num_statements,
            "line_cov_pct": round(line_cov_pct, 2),
            "num_branches": num_branches,
            "covered_branches": covered_branches,
            "missing_branches_count": len(missing_branches),
        })

    is_target = any(tm in fpath.replace("\\", "/") for tm in target_modules)
    if is_target and missing_branches:
        branches_uncovered[fpath] = {
            "missing_branches": missing_branches,
            "missing_lines": missing_lines,
        }

print(f"Total files below 90% line coverage: {len(below_90)}")
below_90.sort(key=lambda x: x["line_cov_pct"])
for b in below_90:
    print(f"{b['path']}: {b['line_cov_pct']}% (statements: {b['statements']}, missing branches: {b['missing_branches_count']})")

print("\n--- Uncovered branches in key modules (rules, optimise, ensemble, simulator) ---")
for mod, info in branches_uncovered.items():
    print(f"\nModule: {mod}")
    print(f"  Missing branches ({len(info['missing_branches'])}): {info['missing_branches'][:20]}")
    print(f"  Missing lines sample: {info['missing_lines'][:10]}")

with open("audit/scratch/coverage_analysis.json", "w", encoding="utf-8") as f:
    json.dump({"below_90": below_90, "branches_uncovered": branches_uncovered}, f, indent=2)
