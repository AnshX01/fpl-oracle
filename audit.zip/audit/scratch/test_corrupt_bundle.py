import tempfile
import json
import hashlib
from pathlib import Path
from fpl_oracle.ml.model_registry import ModelRegistry

with tempfile.TemporaryDirectory() as td:
    tmp = Path(td)
    models_dir = tmp / "models"
    models_dir.mkdir()
    versions_dir = models_dir / "versions"
    v1_dir = versions_dir / "v1.0.0"
    v1_dir.mkdir(parents=True)
    
    # Write legitimate v1 weights
    (v1_dir / "minutes_model.pkl").write_bytes(b"v1_data")
    v1_hash = hashlib.sha256(b"v1_data").hexdigest()
    
    # Active points to v1.0.0, but file on disk is corrupted
    (models_dir / "minutes_model.pkl").write_bytes(b"corrupted_tampered_data")
    
    manifest_data = {
        "active_version": "v1.0.0",
        "versions": [
            {
                "version": "v1.0.0",
                "file_hashes": {"minutes_model.pkl": v1_hash}
            }
        ]
    }
    (models_dir / "manifest.json").write_text(json.dumps(manifest_data))
    
    reg = ModelRegistry()
    reg.models_dir = models_dir
    reg.manifest_path = models_dir / "manifest.json"
    reg.versions_dir = versions_dir
    
    print("Testing verify_weight_integrity on tampered file...")
    try:
        reg.verify_weight_integrity()
        print("UNEXPECTED: verify_weight_integrity passed!")
    except ValueError as e:
        print(f"EXPECTED EXCEPTION: {e}")
        print("Did it automatically rollback to v1_dir version?")
        active_content = (models_dir / "minutes_model.pkl").read_bytes()
        print(f"File content on disk after exception: {active_content}")
        if active_content == b"corrupted_tampered_data":
            print("CONFIRMED: No automatic rollback occurs! Corrupt file remains corrupted on disk and pipeline crashes.")
        else:
            print("Rollback occurred!")
