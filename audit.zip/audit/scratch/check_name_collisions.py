import pandas as pd
from fpl_oracle.data.player_identity import normalize_player_name

df = pd.read_csv("data/historical/master_history.csv")
df["norm_name"] = df["name"].apply(normalize_player_name)

# Check within same season: are there different elements with the same norm_name?
within_season_dupes = df.groupby(["season", "norm_name"])["element"].nunique()
within_season_dupes = within_season_dupes[within_season_dupes > 1]
print("Collisions within the same season (different elements with same norm_name):")
print(within_season_dupes)

# Check across positions: does any norm_name have multiple positions?
pos_counts = df.groupby("norm_name")["position"].nunique()
pos_dupes = pos_counts[pos_counts > 1]
print("\nCollisions across positions (same norm_name, different positions):")
print(pos_dupes)

# Check across teams: does any norm_name have multiple teams within the same gameweek?
round_team_counts = df.groupby(["season", "round", "norm_name"])["team"].nunique()
round_team_dupes = round_team_counts[round_team_counts > 1]
print("\nCollisions within same gameweek (same norm_name, multiple teams):")
print(round_team_dupes)
