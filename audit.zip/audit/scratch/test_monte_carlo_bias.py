import numpy as np
import pandas as pd
from fpl_oracle.league.montecarlo import monte_carlo_simulator

print("=== TESTING MONTE CARLO SIMULATOR MEAN VS MODEL xP ===")

test_players = [
    {"name": "Bench Fodder DEF", "position": "DEF", "expected_points": 1.2, "p_min60": 0.2, "p_play": 0.4, "p_clean_sheet": 0.25},
    {"name": "Starting DEF Good CS", "position": "DEF", "expected_points": 4.5, "p_min60": 0.85, "p_play": 0.90, "p_clean_sheet": 0.40},
    {"name": "Sub-appearance DEF (xP < exp_app_cs)", "position": "DEF", "expected_points": 0.8, "p_min60": 0.1, "p_play": 0.5, "p_clean_sheet": 0.20},
    {"name": "Midfielder Premium", "position": "MID", "expected_points": 7.5, "p_min60": 0.90, "p_play": 0.95, "p_clean_sheet": 0.35},
    {"name": "Forward Low xP", "position": "FWD", "expected_points": 1.5, "p_min60": 0.3, "p_play": 0.6, "p_clean_sheet": 0.0},
    {"name": "Negative xP Defender", "position": "DEF", "expected_points": -0.5, "p_min60": 0.5, "p_play": 0.7, "p_clean_sheet": 0.1},
    {"name": "Zero xP Player", "position": "MID", "expected_points": 0.0, "p_min60": 0.0, "p_play": 0.0, "p_clean_sheet": 0.0},
]

N_TRIALS = 50000

for p in test_players:
    scores = monte_carlo_simulator.simulate_player_trials(p, team_p_cs=p["p_clean_sheet"], n_simulations=N_TRIALS, seed=42)
    sim_mean = float(np.mean(scores))
    sim_std = float(np.std(scores))
    sim_min = float(np.min(scores))
    sim_max = float(np.max(scores))
    bias = sim_mean - p["expected_points"]
    pct_bias = (bias / abs(p["expected_points"]) * 100) if p["expected_points"] != 0 else 0
    print(f"Player: {p['name']:35s} | Target xP: {p['expected_points']:5.2f} | Sim Mean: {sim_mean:5.2f} | Bias: {bias:+6.3f} ({pct_bias:+5.1f}%) | Min: {sim_min:5.2f} | Max: {sim_max:5.2f}")
