import pandas as pd
from fpl_oracle.league.montecarlo import monte_carlo_simulator

user_squad = pd.DataFrame([
    {"element": i, "position": "MID", "team": 1, "expected_points": 5.0, "variance": 4.0, "is_starter": True}
    for i in range(1, 16)
])
projections = pd.DataFrame([
    {"element": i, "position": "MID", "team": 1, "expected_points": 5.0, "variance": 4.0}
    for i in range(1, 30)
])

# Identical rival with identical starters and points
rivals = [
    {
        "entry_id": 101,
        "player_name": "Rival Symmetric",
        "total_points": 300.0,
        "captain_element": 1,
        "squad": [{"element": i, "is_starter": True} for i in range(1, 12)],
    }
]

res = monte_carlo_simulator.simulate_league(
    user_points=300.0,
    user_squad_df=user_squad,
    rival_squads=rivals,
    projections_df=projections,
    horizon_gws=1,
    seed=42,
)

print("Status:", res.get("status"))
print("User win prob in symmetric tie:", res.get("user_win_probability_pct"))
print("Expected final rank in symmetric tie:", res.get("expected_final_rank"))
