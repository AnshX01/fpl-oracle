import os
import re
from pathlib import Path

REPO_ROOT = Path("C:/Users/anshw/Documents/fpl-oracle")
SRC_DIR = REPO_ROOT / "src"

# Search for any dictionary mapping positions to goals, clean sheets, etc.
patterns = [
    (r"\{\s*['\"]GKP['\"]\s*:\s*(\d+)", "GKP goal/CS dict"),
    (r"GOAL_POINTS\s*=", "GOAL_POINTS definition"),
    (r"CLEAN_SHEET_POINTS\s*=", "CLEAN_SHEET_POINTS definition"),
    (r"DEFCON_POINTS\s*=", "DEFCON_POINTS definition"),
    (r"PENALTY_SAVE_POINTS\s*=", "PENALTY_SAVE_POINTS definition"),
    (r"PENALTY_MISS_POINTS\s*=", "PENALTY_MISS_POINTS definition"),
    (r"OWN_GOAL_POINTS\s*=", "OWN_GOAL_POINTS definition"),
    (r"APPEARANCE_GE60\s*=", "APPEARANCE_GE60 definition"),
    (r"HIT_COST_POINTS\s*=", "HIT_COST_POINTS definition"),
    (r"MAX_BANKED_FREE_TRANSFERS\s*=", "MAX_BANKED_FREE_TRANSFERS definition"),
]

results = []
for py_path in SRC_DIR.rglob("*.py"):
    rel = py_path.relative_to(REPO_ROOT).as_posix()
    content = py_path.read_text(encoding="utf-8", errors="ignore")
    lines = content.splitlines()
    for idx, line in enumerate(lines, 1):
        for pat, desc in patterns:
            m = re.search(pat, line)
            if m:
                results.append((rel, idx, desc, line.strip()))

for r in results:
    print(f"{r[0]}:{r[1]} [{r[2]}] {r[3]}")
