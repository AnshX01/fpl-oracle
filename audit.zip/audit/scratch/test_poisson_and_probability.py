import math
import numpy as np
from scipy.stats import poisson
from fpl_oracle.domain.scoring import expected_floor_div, calculate_expected_fixture_points
from fpl_oracle.ml.ensemble import ScoringEnsemble
import pandas as pd

print("=== 1. POISSON FLOOR TESTS ===")
# Test rate = 15.0, 20.0, 25.0 against exact scipy expectation
for rate in [0.0, 0.5, 1.5, 3.0, 5.0, 10.0, 15.0, 20.0, 25.0]:
    fast_val = expected_floor_div(rate, 2, max_k=20)
    # Exact brute-force summation up to k=200
    k_vals = np.arange(0, 200)
    probs = poisson.pmf(k_vals, rate) if rate > 0 else np.array([1.0] + [0.0]*199)
    exact_val = float(np.sum((k_vals // 2) * probs))
    err = abs(fast_val - exact_val)
    print(f"rate={rate:4.1f}: fast={fast_val:.4f}, exact={exact_val:.4f}, diff={err:.6f}")

print("\n=== 2. PROBABILITY COHERENCE TESTS ===")
# Test extreme probability inputs in calculate_expected_fixture_points
test_cases = [
    # (name, p_play, p_min60, expected_minutes, expected_goals_conceded)
    ("min60 > play", 0.3, 0.8, 45.0, 1.2),
    ("play = 0, exp_pts > 0 ?", 0.0, 0.0, 0.0, 0.0),
    ("negative minutes", 0.5, 0.3, -10.0, 1.0),
    ("prob > 1.0", 1.5, 1.2, 90.0, 1.0),
    ("extreme discipline: 2 red cards, 2 own goals", 1.0, 1.0, 90.0, 0.0),
]

for name, p_play, p_min60, exp_min, exp_gc in test_cases:
    try:
        res = calculate_expected_fixture_points(
            position="DEF",
            p_play=p_play,
            p_min60=p_min60,
            p_starts=p_min60,
            expected_minutes=exp_min,
            expected_goals=0.0,
            expected_assists=0.0,
            p_clean_sheet=0.0,
            expected_goals_conceded=exp_gc,
            expected_saves=0.0,
            p_defcon=0.0,
            expected_card_deduction=3.0,
            expected_bonus=0.0,
            expected_own_goals=1.0,
        )
        print(f"Case '{name}': xp={res['expected_points']}, app={res['appearance_pts']}, ded={res['deductions']}")
    except Exception as e:
        print(f"Case '{name}': EXCEPTION: {e}")

print("\n=== 3. SCORING ENSEMBLE RANDOM DECOMPOSITION VERIFICATION ===")
ens = ScoringEnsemble(blend_weights=(1.0, 0.0, 0.0))  # Unblended
np.random.seed(42)
N = 100
df_rand = pd.DataFrame({
    "pos_GKP": [1.0 if i % 4 == 0 else 0.0 for i in range(N)],
    "pos_DEF": [1.0 if i % 4 == 1 else 0.0 for i in range(N)],
    "pos_MID": [1.0 if i % 4 == 2 else 0.0 for i in range(N)],
    "pos_FWD": [1.0 if i % 4 == 3 else 0.0 for i in range(N)],
    "chance_of_playing": np.random.uniform(0, 100, N),
    "roll_own_goals_5": np.random.poisson(0.1, N),
    "roll_penalties_missed_5": np.random.poisson(0.1, N),
})

comp_rand = {
    "p_min60": np.random.uniform(0, 1, N),
    "p_starts": np.random.uniform(0, 1, N),
    "expected_minutes": np.random.uniform(0, 90, N),
    "expected_goals": np.random.exponential(0.3, N),
    "expected_assists": np.random.exponential(0.2, N),
    "p_clean_sheet": np.random.uniform(0, 0.6, N),
    "expected_goals_conceded": np.random.uniform(0, 3.5, N),
    "expected_saves": np.random.uniform(0, 5, N),
    "p_defcon": np.random.uniform(0, 0.5, N),
    "expected_card_deduction": np.random.uniform(0, 0.5, N),
    "expected_bonus": np.random.uniform(0, 1.5, N),
}

preds = ens.aggregate_components(comp_rand, df_rand)
verified_xp = ens.verify_decomposition(preds)
diffs = np.abs(preds["raw_expected_points"] - verified_xp)
max_diff = np.max(diffs)
print(f"Max decomposition discrepancy across {N} random players: {max_diff}")
assert max_diff < 1e-4, f"Decomposition does not match! Max diff: {max_diff}"
print("Decomposition sum verified successfully!")
