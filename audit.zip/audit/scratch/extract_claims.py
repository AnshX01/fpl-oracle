import re
import csv
from pathlib import Path

REPO_ROOT = Path("C:/Users/anshw/Documents/fpl-oracle")

doc_files = [
    "README.md",
    "fpl_oracle_improvement_spec.md",
    "fpl_expert_antigravity_goal_prompt.md",
    "GOAL.md",
    "HANDOFF.md",
    "USER_GUIDE.md",
    "DECISIONS.md",
    "PLAN.md",
    "SETUP.md",
    "reports/spec_coverage.md",
    "reports/baseline.md",
]

claims_data = []

# Let's inspect doc lines mentioning key claims
patterns = [
    r"zero leakage",
    r"426 test",
    r"461 test",
    r"57 feature",
    r"Poisson floor",
    r"rollback",
    r"12-hour cache",
    r"seven jobs",
    r"100% compliant",
    r"100% pass",
    r"under 1\.5 second",
    r"GKP.*10",
    r"5 banked",
    r"Dixon-Coles",
    r"conformal",
    r"quantile",
    r"stacking",
    r"single-reconciler",
    r"prompt injection",
    r"offline fallback",
    r"three-per-club",
    r"50% rule",
    r"beam search",
    r"Set 1",
    r"GW19",
]

for doc_rel in doc_files:
    p = REPO_ROOT / doc_rel
    if not p.exists():
        continue
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        for idx, line in enumerate(f, 1):
            for pat in patterns:
                if re.search(pat, line, re.IGNORECASE):
                    claims_data.append((doc_rel, idx, line.strip()))
                    break

print(f"Found {len(claims_data)} claim candidates.")
with open(REPO_ROOT / "audit/scratch/raw_claims.txt", "w", encoding="utf-8") as f:
    for doc, idx, text in claims_data:
        f.write(f"{doc}:{idx}: {text}\n")
