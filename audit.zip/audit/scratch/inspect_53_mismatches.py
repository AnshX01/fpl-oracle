import pandas as pd
from fpl_oracle.rules.scoring import calculate_match_points

df = pd.read_csv('data/historical/master_history.csv')
managers = ['Arteta', 'Guardiola', 'Emery', 'Iraola', 'Maresca', 'Glasner', 'Moyes', 'McKenna', 'Slot', 'Amorim', 'Howe', 'Juric', 'Postecoglou', 'Potter', 'Frank', 'Nistelrooij', 'Cooper', 'Dyche', 'O\'Neil', 'Lopetegui', 'Martin']
is_mgr = df['name'].apply(lambda n: any(m in str(n) for m in managers) and df.loc[df['name']==n, 'minutes'].max() == 0)

player_df = df[~is_mgr].copy()

mismatches = []
for idx, row in player_df.iterrows():
    pts = calculate_match_points(
        position=str(row['position']),
        minutes=int(row['minutes']),
        goals_scored=int(row['goals_scored']),
        assists=int(row['assists']),
        clean_sheet=bool(row['clean_sheets'] == 1),
        goals_conceded=int(row['goals_conceded']),
        saves=int(row['saves']),
        penalties_saved=int(row['penalties_saved']),
        penalties_missed=int(row['penalties_missed']),
        yellow_cards=int(row['yellow_cards']),
        red_cards=int(row['red_cards']),
        own_goals=int(row['own_goals']),
        defensive_contribution_actions=row.get('defensive_contribution', 0) if pd.notna(row.get('defensive_contribution', 0)) else 0,
        bonus=int(row['bonus']),
        season=str(row['season']),
    )
    if pts != row['total_points']:
        row_dict = row.to_dict()
        row_dict['recomputed'] = pts
        row_dict['diff'] = pts - row['total_points']
        mismatches.append(row_dict)

m_df = pd.DataFrame(mismatches)
print(f"Count of mismatches: {len(m_df)}")
cols = ['season', 'round', 'name', 'position', 'minutes', 'goals_scored', 'assists', 'clean_sheets', 'goals_conceded', 'saves', 'defensive_contribution', 'bonus', 'total_points', 'recomputed', 'diff']
print(m_df[cols].to_string())
