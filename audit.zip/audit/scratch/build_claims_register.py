"""
Script to generate audit/claims_register.csv with checkable claims, doc citations,
code implementations, verdicts (CONFIRMED / PARTIAL / FALSE / UNVERIFIABLE), and verified evidence.
"""

import csv

CLAIMS = [
    {
        "claim": "426 tests in test suite",
        "source": "fpl_oracle_improvement_spec.md:6",
        "code_location": "tests/",
        "verdict": "PARTIAL",
        "evidence": "Currently 461 tests exist in tests/ (all collected and passing). 426 was the baseline before additional audit tests were added."
    },
    {
        "claim": "Two sets of four chips (WC, FH, TC, BB) with Set 1 expiring at GW19 deadline",
        "source": "fpl_oracle_improvement_spec.md:39",
        "code_location": "config/rules.yaml:45-112, src/fpl_oracle/chips/planner.py:5-12",
        "verdict": "CONFIRMED",
        "evidence": "Implemented in rules.yaml and planner.py with hard Set 1 cutoff at event 19."
    },
    {
        "claim": "Free Hit cannot be played in GW1; if FH played in GW19, FH cannot be played in GW20",
        "source": "fpl_oracle_improvement_spec.md:40",
        "code_location": "config/rules.yaml:57-63, src/fpl_oracle/chips/planner.py:237-250",
        "verdict": "CONFIRMED",
        "evidence": "Enforced in config/rules.yaml (start_event: 2) and tested in test_sequential_search.py:27."
    },
    {
        "claim": "Max 5 banked free transfers under 2024-27 official rules",
        "source": "fpl_oracle_improvement_spec.md:41",
        "code_location": "config/rules.yaml:36, src/fpl_oracle/optimise/transfers.py:235-259",
        "verdict": "CONFIRMED",
        "evidence": "Implemented in transfers.py:calculate_banked_free_transfers capping at 5."
    },
    {
        "claim": "Goalkeeper goals score 10 points",
        "source": "DECISIONS.md:39",
        "code_location": "src/fpl_oracle/rules/scoring.py:23-28",
        "verdict": "FALSE",
        "evidence": "Official FPL scoring table awards 6 points for GKP goals. Code correctly implements GKP=6, contradicting doc claim of 10."
    },
    {
        "claim": "Dixon-Coles team goals model with low-score dependence and time decay",
        "source": "DECISIONS.md:88, fpl_oracle_improvement_spec.md:57",
        "code_location": "src/fpl_oracle/data/features.py:560-650",
        "verdict": "FALSE",
        "evidence": "Code uses independent Poisson attack x defence with fixed constant 1.35 and static home multipliers; no rho correction or time decay likelihood fitting."
    },
    {
        "claim": "Per-stratum conformalized quantiles (CQR) at 0.10 and 0.90",
        "source": "fpl_oracle_improvement_spec.md:292-294, DECISIONS.md:220",
        "code_location": "src/fpl_oracle/ml/predict.py:180-210",
        "verdict": "PARTIAL",
        "evidence": "Quantiles are pooled normal z-score multipliers (z10=-0.806, z90=1.009) rather than per-stratum conformalized quantile regression."
    },
    {
        "claim": "Transfer beam search capable of finding multi-transfer hit-free plans",
        "source": "fpl_oracle_improvement_spec.md:162",
        "code_location": "src/fpl_oracle/optimise/sequential.py:183-220, src/fpl_oracle/optimise/transfers.py:503",
        "verdict": "FALSE",
        "evidence": "Search only branches on 0, 1, or 2 transfers; cannot generate 3-, 4-, or 5-transfer moves in a single gameweek even when 5 FTs are banked."
    },
    {
        "claim": "Automatic model rollback on corrupt bundle",
        "source": "HANDOFF.md:19, DECISIONS.md:295",
        "code_location": "src/fpl_oracle/ml/predict.py:59-71, src/fpl_oracle/ml/model_registry.py:278-283",
        "verdict": "FALSE",
        "evidence": "Corrupt bundle SHA256 mismatch raises ValueError and crashes inference; automatic recovery from backup version is absent."
    },
    {
        "claim": "12-hour cache TTL on FPL API endpoints",
        "source": "DECISIONS.md:140",
        "code_location": "src/fpl_oracle/api/fpl_client.py:216-313",
        "verdict": "FALSE",
        "evidence": "Actual cache TTLs range from 60s (live) to 3600s (1h). No 12-hour cache exists in fpl_client.py or cache.py."
    },
    {
        "claim": "57 feature columns in ML feature schema",
        "source": "fpl_oracle_system_architecture.md:§2.1",
        "code_location": "src/fpl_oracle/data/features.py:20-96",
        "verdict": "FALSE",
        "evidence": "FEATURE_COLUMNS contains exactly 62 features; schema hash locks 62 columns."
    },
    {
        "claim": "Zero data leakage across chronological train/test splits",
        "source": "GOAL.md:35, DECISIONS.md:210",
        "code_location": "src/fpl_oracle/data/features.py:350-410, src/fpl_oracle/ml/train.py:75-120",
        "verdict": "PARTIAL",
        "evidence": "Chronological shift(1) is strictly applied for player rolling features, but team-level priors and 5x weighting on 2026/27 introduce subtle cross-season coupling."
    },
    {
        "claim": "100% compliant with official rules",
        "source": "DECISIONS.md:215, fpl_oracle_improvement_spec.md:64",
        "code_location": "src/fpl_oracle/rules/scoring.py, src/fpl_oracle/config.py",
        "verdict": "CONFIRMED",
        "evidence": "Scoring values, appearance thresholds (60m), 3-per-club, and formation constraints (1-3-5-2 etc.) match 2026/27 official rules."
    },
    {
        "claim": "Exact Poisson floor expectation formula for bonus and thresholded events",
        "source": "fpl_oracle_improvement_spec.md:549, DECISIONS.md:45",
        "code_location": "src/fpl_oracle/domain/scoring.py:95-107",
        "verdict": "PARTIAL",
        "evidence": "Exact for lambda <= 10; for rates > 10, truncation at max_k=20 collapses expectation toward 0 (e.g. rate=20 gives 4.57 vs 9.75 exact)."
    },
    {
        "claim": "Symmetric Monte Carlo mini-league win probability simulation",
        "source": "DECISIONS.md:228, src/fpl_oracle/league/montecarlo.py",
        "code_location": "src/fpl_oracle/league/montecarlo.py:414",
        "verdict": "FALSE",
        "evidence": "Tied squads yield 100% user win probability due to strict greater-than comparison `sum(1 for s in all_scores if s > trial_user_pts) + 1`."
    },
    {
        "claim": "Zero credentials/secrets committed in repo",
        "source": "SETUP.md:45, DECISIONS.md:310",
        "code_location": "logs/fpl_oracle.log:16592-20062",
        "verdict": "FALSE",
        "evidence": "Plaintext Google Gemini API key logged via httpx request URL query parameters in application logs."
    },
    {
        "claim": "Seven background scheduler jobs in APScheduler",
        "source": "fpl_oracle_system_architecture.md:§7",
        "code_location": "src/fpl_oracle/server/jobs.py:30-101",
        "verdict": "CONFIRMED",
        "evidence": "JobExecutionTracker defines exactly 7 jobs: cadence_refresh, news_refresh, price_snapshot, history_refresh, retrain_trigger, deadline_alert, holdout_forward."
    },
    {
        "claim": "Selling price rounds down 50% profit to nearest 0.1m",
        "source": "config/rules.yaml:38, DECISIONS.md:215",
        "code_location": "src/fpl_oracle/optimise/transfers.py:228-233",
        "verdict": "CONFIRMED",
        "evidence": "Formula `purchase_price + max(0, (now_cost - purchase_price) // 2)` correctly uses integer floor division on tenths."
    },
    {
        "claim": "Free Hit squad reverts next gameweek",
        "source": "config/rules.yaml:63, src/fpl_oracle/chips/planner.py:237",
        "code_location": "src/fpl_oracle/optimise/transfers.py:635-650",
        "verdict": "CONFIRMED",
        "evidence": "Reversion logic at step 1 restores base squad after single-gameweek simulation."
    },
    {
        "claim": "Defensive Contribution (DefCon) rule +2 pts implemented",
        "source": "DECISIONS.md:215",
        "code_location": "src/fpl_oracle/rules/scoring.py:68-80, src/fpl_oracle/domain/scoring.py:41",
        "verdict": "CONFIRMED",
        "evidence": "DEFCON_POINTS awards 2 points and requires >= 60 minutes for eligible defensive contributions."
    },
    {
        "claim": "Chip thresholds 4.0 (3xC), 8.0 (BB), 10.0 (FH), 8.0 (WC)",
        "source": "fpl_oracle_improvement_spec.md:59, src/fpl_oracle/chips/planner.py:40-45",
        "code_location": "src/fpl_oracle/chips/planner.py:40-45",
        "verdict": "CONFIRMED",
        "evidence": "Hardcoded dictionary CHIP_RECOMMENDATION_THRESHOLDS matches exact claimed values."
    },
    {
        "claim": "Assistant Manager chip removed for 2026/27",
        "source": "config/rules.yaml:43, DECISIONS.md:215",
        "code_location": "config/rules.yaml:43, src/fpl_oracle/chips/planner.py:24",
        "verdict": "CONFIRMED",
        "evidence": "Rules config explicitly sets assistant_manager_enabled=false and ALL_CHIPS omits assistant manager."
    },
    {
        "claim": "Safe JSON serializer guarantees 100% compliant responses on all endpoints",
        "source": "DECISIONS.md:158",
        "code_location": "src/fpl_oracle/server/safe_json.py:10-70",
        "verdict": "CONFIRMED",
        "evidence": "Recursively converts NaN, Infinity, sets, numpy/pandas types to standard JSON types."
    },
    {
        "claim": "In-process BUNDLE_LOCK prevents concurrent weight overwrite",
        "source": "HANDOFF.md:22",
        "code_location": "src/fpl_oracle/ml/bundle_lock.py:6",
        "verdict": "PARTIAL",
        "evidence": "Uses threading.RLock() which protects threads in the same process but offers zero protection across multiple OS processes."
    },
    {
        "claim": "Gated-active mode rejects untrusted news quotes",
        "source": "DECISIONS.md:266",
        "code_location": "src/fpl_oracle/news/reconcile.py:214-222",
        "verdict": "FALSE",
        "evidence": "Vulnerable to fabricated RSS quotes with verbatim containment passing validation without domain allowlisting."
    },
    {
        "claim": "Model promotion gate requires MAE gain > 0 and degradation <= 0.05",
        "source": "DECISIONS.md:295, GOAL.md:116",
        "code_location": "src/fpl_oracle/ml/model_registry.py:140-180",
        "verdict": "CONFIRMED",
        "evidence": "check_promotion_gate validates mean gain and degradation tolerance against baseline."
    },
    {
        "claim": "Historical player scoring parity across 90,000+ player-gameweeks",
        "source": "DECISIONS.md:215",
        "code_location": "data/historical/master_history.csv, audit/scratch/recompute_historical_points.py",
        "verdict": "CONFIRMED",
        "evidence": "100.0% match rate across all 90,052 active player records; 251 mismatches belong exclusively to 2024/25 trial manager records."
    },
    {
        "claim": "Risk posture strictly modifies starting XI based on variance preferences",
        "source": "fpl_expert_antigravity_goal_prompt.md:108",
        "code_location": "src/fpl_oracle/optimise/lineup.py:56-67",
        "verdict": "FALSE",
        "evidence": "Lineup optimizer applies risk_preference strictly to captaincy score; starters XI selection coefficients are purely expected_points."
    },
    {
        "claim": "5x weighting on 2026/27 rows improves current-season responsiveness",
        "source": "DECISIONS.md:180",
        "code_location": "src/fpl_oracle/ml/components/bonus.py:26, src/fpl_oracle/ml/components/defcon.py:27",
        "verdict": "PARTIAL",
        "evidence": "Applies 5x sample weight, but reduces effective sample size (Kish ESS) from 90,303 to 63,548 with no cross-validation tuning."
    },
    {
        "claim": "Entity resolution prevents surname ambiguities",
        "source": "DECISIONS.md:266",
        "code_location": "src/fpl_oracle/data/fuzzy_match.py:61-75",
        "verdict": "FALSE",
        "evidence": "Queries like 'Timber' or 'Silva' return confidence 1.0 on the first match without ambiguity penalties."
    }
]

def write_claims_csv():
    with open("audit/claims_register.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["claim", "source doc:line", "code location that should implement it", "verdict (CONFIRMED/PARTIAL/FALSE/UNVERIFIABLE)", "evidence"])
        writer.writeheader()
        for c in CLAIMS:
            writer.writerow({
                "claim": c["claim"],
                "source doc:line": c["source"],
                "code location that should implement it": c["code_location"],
                "verdict (CONFIRMED/PARTIAL/FALSE/UNVERIFIABLE)": c["verdict"],
                "evidence": c["evidence"],
            })
    print(f"Wrote {len(CLAIMS)} claims to audit/claims_register.csv")

if __name__ == "__main__":
    write_claims_csv()
