import pandas as pd
import numpy as np
from pathlib import Path
from fpl_oracle.rules.scoring import calculate_match_points

df = pd.read_csv("data/historical/master_history.csv")
print(f"Total rows in master_history: {len(df)}")
print("Seasons present:", df["season"].value_counts().to_dict())

recalculated = []
for idx, row in df.iterrows():
    pts = calculate_match_points(
        position=str(row["position"]),
        minutes=int(row["minutes"]),
        goals_scored=int(row["goals_scored"]),
        assists=int(row["assists"]),
        clean_sheet=bool(row["clean_sheets"] == 1),
        goals_conceded=int(row["goals_conceded"]),
        saves=int(row["saves"]),
        penalties_saved=int(row["penalties_saved"]),
        penalties_missed=int(row["penalties_missed"]),
        yellow_cards=int(row["yellow_cards"]),
        red_cards=int(row["red_cards"]),
        own_goals=int(row["own_goals"]),
        defensive_contribution_actions=row.get("defensive_contribution", 0) if pd.notna(row.get("defensive_contribution", 0)) else 0,
        bonus=int(row["bonus"]),
        season=str(row["season"]),
    )
    recalculated.append(pts)

df["recomputed_points"] = recalculated
df["diff"] = df["recomputed_points"] - df["total_points"]

mismatches = df[df["diff"] != 0]
mismatch_count = len(mismatches)
total_count = len(df)
rate = (mismatch_count / total_count) * 100

print(f"Total mismatches: {mismatch_count} / {total_count} ({rate:.4f}%)")

if mismatch_count > 0:
    print("\nMismatch distribution by season:")
    print(mismatches["season"].value_counts())
    print("\nMismatch distribution by position:")
    print(mismatches["position"].value_counts())
    print("\nSample mismatches:")
    sample_cols = ["season", "name", "position", "minutes", "goals_conceded", "clean_sheets", "defensive_contribution", "bonus", "total_points", "recomputed_points", "diff"]
    print(mismatches[sample_cols].head(20).to_string())
    
    print("\nSummary of diff values:")
    print(mismatches["diff"].value_counts().head(10))
