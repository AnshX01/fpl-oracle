import pandas as pd
import numpy as np

df = pd.read_csv("data/historical/master_history.csv")
print("Total rows:", len(df))
rows_2026 = (df["season"] == "2026-27").sum()
rows_other = (df["season"] != "2026-27").sum()
print(f"2026-27 rows: {rows_2026} ({rows_2026/len(df)*100:.2f}%)")
print(f"Other seasons rows: {rows_other}")

# DefCon model: 5x weight on 2026-27
w_defcon = np.where(df["season"] == "2026-27", 5.0, 1.0)
ess_defcon = (np.sum(w_defcon) ** 2) / np.sum(w_defcon ** 2)
print(f"\nDefCon sample weighting (5x):")
print(f"  Sum of weights: {np.sum(w_defcon):.1f}")
print(f"  Effective Sample Size (Kish's ESS): {ess_defcon:.1f} (vs {len(df)} nominal, reduction of {len(df)-ess_defcon:.1f})")

# Bonus model: 4x weight on 2026-27
w_bonus = np.where(df["season"] == "2026-27", 4.0, 1.0)
ess_bonus = (np.sum(w_bonus) ** 2) / np.sum(w_bonus ** 2)
print(f"\nBonus sample weighting (4x):")
print(f"  Sum of weights: {np.sum(w_bonus):.1f}")
print(f"  Effective Sample Size (Kish's ESS): {ess_bonus:.1f} (vs {len(df)} nominal, reduction of {len(df)-ess_bonus:.1f})")

# For players with minutes > 0:
df_active = df[df["minutes"] > 0]
w_act_5x = np.where(df_active["season"] == "2026-27", 5.0, 1.0)
ess_act_5x = (np.sum(w_act_5x) ** 2) / np.sum(w_act_5x ** 2)
print(f"\nActive players (minutes > 0, N={len(df_active)}):")
print(f"  2026-27 active rows: {(df_active['season'] == '2026-27').sum()}")
print(f"  Active DefCon ESS: {ess_act_5x:.1f}")
