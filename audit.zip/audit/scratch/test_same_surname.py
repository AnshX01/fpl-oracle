from fpl_oracle.data.fuzzy_match import FuzzyPlayerMatcher
from fpl_oracle.api.models import Element

matcher = FuzzyPlayerMatcher()

elements = [
    Element(id=10, web_name="J.Timber", first_name="Jurrien", second_name="Timber", team=1, element_type=2, status="a", now_cost=55),
    Element(id=20, web_name="Q.Timber", first_name="Quinten", second_name="Timber", team=5, element_type=3, status="a", now_cost=60),
    Element(id=30, web_name="B.Silva", first_name="Bernardo", second_name="Silva", team=11, element_type=3, status="a", now_cost=70),
    Element(id=40, web_name="F.Silva", first_name="Fabio", second_name="Silva", team=20, element_type=4, status="a", now_cost=50),
]

for q in ["Timber", "Silva", "Jurrien Timber", "Bernardo Silva"]:
    m = matcher.match_single_name(q, elements)
    matched = m["matched"]
    print(f"Query: '{q:15s}' -> Matched: {matched['full_name']} (ID {matched['element']}) Score: {matched['score']}")
    if m["alternatives"]:
        print(f"  Alternatives: {[a['full_name'] + ' (ID ' + str(a['element']) + ')' for a in m['alternatives']]}")
