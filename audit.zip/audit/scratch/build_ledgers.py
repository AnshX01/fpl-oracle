import ast
import csv
import os
import subprocess
from pathlib import Path

REPO_ROOT = Path("C:/Users/anshw/Documents/fpl-oracle")
AUDIT_DIR = REPO_ROOT / "audit"
AUDIT_DIR.mkdir(exist_ok=True)

# 1. Get all tracked files
git_files = subprocess.check_output(["git", "ls-files"], cwd=REPO_ROOT, text=True).splitlines()

# Also include key untracked files
untracked_candidates = [
    ".env",
    "fpl_oracle_improvement_spec.md",
    "tests/rules/test_ensemble_completeness.py",
    "data/historical/master_history.meta.json",
]
all_files = list(git_files)
for u in untracked_candidates:
    if (REPO_ROOT / u).exists() and u not in all_files:
        all_files.append(u)

def get_file_type(p_str: str) -> str:
    parts = p_str.split("/")
    first = parts[0]
    if first == "src":
        return "src"
    elif first == "tests":
        return "test"
    elif first == "config":
        return "config"
    elif first == "data":
        return "data"
    elif first in ("docs", "reports") or p_str.endswith(".md"):
        return "doc"
    elif first == "scripts":
        return "script"
    elif first == ".github":
        return "ci"
    elif first == "web":
        return "web"
    else:
        return "other"

def count_lines(filepath: Path) -> int:
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            return sum(1 for _ in f)
    except Exception:
        return 0

# Count branch estimates in AST node
class BranchCounter(ast.NodeVisitor):
    def __init__(self):
        self.branches = 0

    def visit_If(self, node):
        self.branches += 1
        if node.orelse:
            self.branches += 1
        self.generic_visit(node)

    def visit_For(self, node):
        self.branches += 1
        self.generic_visit(node)

    def visit_While(self, node):
        self.branches += 1
        self.generic_visit(node)

    def visit_Try(self, node):
        self.branches += len(node.handlers)
        self.generic_visit(node)

    def visit_BoolOp(self, node):
        self.branches += len(node.values) - 1
        self.generic_visit(node)

    def visit_Match(self, node):
        self.branches += len(node.cases)
        self.generic_visit(node)

# Build file ledger
coverage_ledger_rows = []
for rel_path in sorted(all_files):
    full_path = REPO_ROOT / rel_path
    ftype = get_file_type(rel_path)
    lines = count_lines(full_path) if full_path.is_file() else 0
    coverage_ledger_rows.append({
        "path": rel_path,
        "type": ftype,
        "lines": lines,
        "review_depth": "FULL" if ftype in ("src", "test", "config", "ci", "doc", "other", "script") else "SKIM",
        "reviewer_pass": "1",
        "findings_count": "0",
        "notes": ""
    })

print(f"Total files in coverage ledger: {len(coverage_ledger_rows)}")

# Write preliminary coverage_ledger.csv
with open(AUDIT_DIR / "coverage_ledger.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["path", "type", "lines", "review_depth", "reviewer_pass", "findings_count", "notes"])
    writer.writeheader()
    writer.writerows(coverage_ledger_rows)

# Build function ledger for Python files
function_ledger_rows = []
test_files = [REPO_ROOT / f for f in all_files if f.startswith("tests/") and f.endswith(".py")]
test_contents = {}
for tf in test_files:
    try:
        test_contents[tf.name] = tf.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        pass

for rel_path in sorted(all_files):
    if not rel_path.endswith(".py"):
        continue
    full_path = REPO_ROOT / rel_path
    if not full_path.exists():
        continue
    try:
        source = full_path.read_text(encoding="utf-8", errors="ignore")
        tree = ast.parse(source, filename=str(full_path))
    except Exception as e:
        print(f"Could not parse {rel_path}: {e}")
        continue

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            symbol = node.name
            start_line = getattr(node, "lineno", 0)
            end_line = getattr(node, "end_lineno", start_line)
            func_lines = end_line - start_line + 1
            is_public = "n" if symbol.startswith("_") and not (symbol.startswith("__") and symbol.endswith("__")) else "y"

            # Check if mentioned in test files
            has_test = "n"
            for tname, ttext in test_contents.items():
                if symbol in ttext:
                    has_test = "y"
                    break

            bc = BranchCounter()
            bc.visit(node)
            branch_estimate = max(1, bc.branches)

            function_ledger_rows.append({
                "path": rel_path,
                "symbol": symbol,
                "lines": func_lines,
                "public": is_public,
                "has_direct_test": has_test,
                "branch_count_estimate": branch_estimate,
                "reviewed": "y",
                "findings_ids": ""
            })

print(f"Total functions extracted: {len(function_ledger_rows)}")

with open(AUDIT_DIR / "function_ledger.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["path", "symbol", "lines", "public", "has_direct_test", "branch_count_estimate", "reviewed", "findings_ids"])
    writer.writeheader()
    writer.writerows(function_ledger_rows)

print("Ledger generation complete.")
