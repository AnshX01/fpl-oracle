"""
Script to annotate coverage_ledger.csv and function_ledger.csv with finding IDs.
"""

import pandas as pd

FILE_FINDINGS = {
    "logs/fpl_oracle.log": ("F-001", 1),
    "src/fpl_oracle/league/montecarlo.py": ("F-002", 2),
    "src/fpl_oracle/news/reconcile.py": ("F-003", 2),
    "src/fpl_oracle/news/gemini_extractor.py": ("F-003,F-015", 2),
    "src/fpl_oracle/domain/scoring.py": ("F-004", 2),
    "src/fpl_oracle/optimise/sequential.py": ("F-005,F-011", 2),
    "src/fpl_oracle/optimise/transfers.py": ("F-005", 2),
    "src/fpl_oracle/ml/predict.py": ("F-006", 2),
    "src/fpl_oracle/ml/model_registry.py": ("F-006", 2),
    "src/fpl_oracle/chips/planner.py": ("F-007", 3),
    "src/fpl_oracle/ml/bundle_lock.py": ("F-008", 2),
    "src/fpl_oracle/ml/components/bonus.py": ("F-009", 2),
    "src/fpl_oracle/ml/components/defcon.py": ("F-009", 2),
    "src/fpl_oracle/data/fuzzy_match.py": ("F-010", 2),
    "src/fpl_oracle/optimise/lineup.py": ("F-011", 2),
    "src/fpl_oracle/data/features.py": ("F-012,F-016", 1),
    "tests/test_league_strategy_mc.py": ("F-013", 1),
    "src/fpl_oracle/rules/scoring.py": ("F-014", 1),
    "src/fpl_oracle/optimise/squad.py": ("F-014,F-015", 1),
    "src/fpl_oracle/llm/tools.py": ("F-015", 1),
    "src/fpl_oracle/llm/agent.py": ("F-015", 1),
}

FUNCTION_FINDINGS = {
    ("src/fpl_oracle/league/montecarlo.py", "simulate_league_ranks"): "F-002",
    ("src/fpl_oracle/domain/scoring.py", "expected_floor_div"): "F-004",
    ("src/fpl_oracle/optimise/sequential.py", "search_sequences"): "F-005",
    ("src/fpl_oracle/ml/predict.py", "load_active_bundle"): "F-006",
    ("src/fpl_oracle/chips/planner.py", "generate_chip_strategy"): "F-007",
    ("src/fpl_oracle/data/fuzzy_match.py", "fuzzy_match_player"): "F-010",
    ("src/fpl_oracle/optimise/lineup.py", "select_lineup_and_captain"): "F-011",
}

def annotate_ledgers():
    cov_df = pd.read_csv("audit/coverage_ledger.csv")
    cov_df["notes"] = cov_df["notes"].fillna("").astype(str)
    for idx, row in cov_df.iterrows():
        path = str(row["path"]).replace("\\", "/")
        if path in FILE_FINDINGS:
            f_ids, p_num = FILE_FINDINGS[path]
            cov_df.at[idx, "findings_count"] = len(f_ids.split(","))
            cov_df.at[idx, "reviewer_pass"] = p_num
            cov_df.at[idx, "notes"] = f"Findings: {f_ids}"
    cov_df.to_csv("audit/coverage_ledger.csv", index=False)
    print("Updated audit/coverage_ledger.csv")

    func_df = pd.read_csv("audit/function_ledger.csv")
    func_df["findings_ids"] = func_df["findings_ids"].fillna("").astype(str)
    for idx, row in func_df.iterrows():
        path = str(row["path"]).replace("\\", "/")
        symbol = str(row["symbol"])
        key = (path, symbol)
        if key in FUNCTION_FINDINGS:
            func_df.at[idx, "findings_ids"] = FUNCTION_FINDINGS[key]
    func_df.to_csv("audit/function_ledger.csv", index=False)
    print("Updated audit/function_ledger.csv")

if __name__ == "__main__":
    annotate_ledgers()
